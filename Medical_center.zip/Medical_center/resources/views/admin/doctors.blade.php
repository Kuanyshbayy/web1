<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipakerler</title>
</head>
<body>
<a href="{{url('admin')}}">Arqag'a</a><br><br>
<a href="{{route('admin_doctors.create')}}">Shipakerlerdi qosiw</a><br><br>
<table border="1">
    <tr>
        <th>№</th>
        <th>F.I.O</th>
        <th>Bo'limi</th>
        <th>Is tajiriybesi / jil</th>
        <th>su'wret</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    @foreach ($doctors as $doctor)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$doctor->name}}</td>
            @foreach($categories as $category)
            @if($doctor->category_id == $category->id)
                <td>{{ $category->name}}</td>
            @endif
            @endforeach
            <td>{{$doctor->experience}}</td>
            <td><img src="{{$doctor->image}}" width="100px" alt="img"></td>
            <td><a href="{{route('admin_doctors.edit',$doctor->id)}}"><button>edit</button></a></td>
            <td><form action="{{ route('admin_doctors.destroy',$doctor) }}" method="POST">
                        @method('DELETE')
                        @csrf
                        <input type="submit" value="delete">
                 </form>
            </td>
        </tr>
    @endforeach
   </table>
</body>
</html>