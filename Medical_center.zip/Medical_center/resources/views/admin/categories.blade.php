<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategoriyalar</title>
</head>
<body>
    <a href="{{url('admin')}}">Arqaga</a><br><br>
    <form action="{{route('admin_categories.store')}}" method="POST">
        @csrf
        <input type="text" name="name" placeholder="kategoriya" required=""><br><br>
        <textarea name="description" placeholder="description" cols="30" rows="10"></textarea><br><br>
        <input type="submit" style="color:red" value="jiberiw">
    </form><br><br>
   <table border="1">
    <tr>
        <th>№</th>
        <th>name</th>
        <th>description</th>
        <th>edit</th>
        <th>delete</th>
    </tr>
    @foreach ($categories as $category)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$category->name}}</td>
            <td>{{$category->description}}</td> 
            <td><a href="{{route('admin_categories.edit',$category->id)}}"><button>edit</button></a></td>
            <td><form action="{{ route('admin_categories.destroy',$category) }}" method="POST">
                        @method('DELETE')
                        @csrf
                        <input type="submit" value="delete">
                 </form>
            </td>
        </tr>
    @endforeach
   </table>
</body>
</html>