<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Doctor;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $doctors = Doctor::get();
        $categories = Category::get();
        
        return view('admin.doctors',['doctors'=>$doctors,'categories'=>$categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::get();

        return view('admin.doctor_add',[
            'categories'=>$categories
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'category_id'=>'required', 
            'experience'=>'required',
            'image'=>'mimes:jpeg,jpg,png|required|max:100000',
           
        ]);

        $imageName = time().".".$request->image->getClientOriginalExtension();
        $request->image->move(public_path('/images'),$imageName);
        Doctor::create([
            'name'=>$request->name,
            'category_id'=>$request->category_id, 
            'experience'=>$request->experience,
            'image'=>'images/'.$imageName,
           
        ]);
        return redirect('admin_doctors');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        $doctor = Doctor::find($id);
        $categories = Category::get();
        return view('admin.doctor_edit',[
            "doctor"=>$doctor,
            'categories'=>$categories
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(!isset($request->image))
        {
            $img_url = Doctor::where('id',$id)->get()[0]['image'];
        }
        else
        {
            $imageName = time().".".$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/images'),$imageName);
            $img_url = 'images/'.$imageName;
        }

        Doctor::findOrFail($id)->update([
            'name'=>$request->name,
            'category_id'=>$request->category_id, 
            'experience'=>$request->experience,
            'image'=>$img_url,
        ]);
        return redirect('admin_doctors');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Doctor::destroy($id);

        return redirect('admin_doctors');  
    }
}
