<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Symfony\Component\VarDumper\Caster\DoctrineCaster;

class IndexController extends Controller
{
   public function index()
   {
    $categories = Category::get();
    $doctors = Doctor::get();
   
    return view('index',[
        'categories'=>$categories,
        'doctors'=>$doctors,
        
    ]);
   }

   public function detail_category($id)
   {
    $category = Category::find($id);
    $categories = Category::get();
    $doctors = Doctor::Where('category_id',$id)->get();
    return view('detail_category',[
        'category'=>$category,
        'doctors'=>$doctors,
        'categories'=>$categories
    ]);
   }
}
