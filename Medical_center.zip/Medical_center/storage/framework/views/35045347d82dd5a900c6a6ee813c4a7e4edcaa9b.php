<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategoriyalar</title>
</head>
<body>
    <a href="<?php echo e(url('admin')); ?>">Arqaga</a><br><br>
    <form action="<?php echo e(route('admin_categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="kategoriya" required=""><br><br>
        <textarea name="description" placeholder="description" cols="30" rows="10"></textarea><br><br>
        <input type="submit" style="color:red" value="jiberiw">
    </form><br><br>
   <table border="1">
    <tr>
        <th>№</th>
        <th>name</th>
        <th>description</th>
        <th>edit</th>
        <th>delete</th>
    </tr>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->description); ?></td> 
            <td><a href="<?php echo e(route('admin_categories.edit',$category->id)); ?>"><button>edit</button></a></td>
            <td><form action="<?php echo e(route('admin_categories.destroy',$category)); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="delete">
                 </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
</body>
</html><?php /**PATH C:\MAMP\htdocs\Medical_center\resources\views/admin/categories.blade.php ENDPATH**/ ?>