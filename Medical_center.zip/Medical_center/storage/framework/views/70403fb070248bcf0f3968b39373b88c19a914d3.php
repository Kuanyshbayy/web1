<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin_doctors')); ?>">Arqaga</a><br><br>

    <form action="<?php echo e(route('admin_doctors.update',$doctor->id)); ?>" method="POST" enctype="multipart/form-data">
       
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label style="color: red;" for="">F.I.O kiritin: </label>
        <input type="text" name="name" placeholder="shipaker ati" value="<?php echo e($doctor->name); ?>" required=""><br><br>
        <label style="color: red;" for="">Bo'limin kiritin: </label>
        <select name="category_id" id="" >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->id == $doctor->category_id): ?>
            {
                <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            }
            <?php else: ?>
            {
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

            }
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label style="color: red;" for="">Is tajiriybesin kiritin: </label>
        <input type="number" name="experience" value="<?php echo e($doctor->experience); ?>" placeholder="Is tajiriybesi" required=""><br><br>
        <label style="color: red;" for="">Shipaker suwreti: </label>
        <input type="file" name="image"><br><br>
        <input type="submit">
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\Medical_center\resources\views/admin/doctor_edit.blade.php ENDPATH**/ ?>