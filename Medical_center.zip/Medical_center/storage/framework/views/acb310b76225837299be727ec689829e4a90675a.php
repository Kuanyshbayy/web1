<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Medical center</title>
	
    <!-- css -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/cubeportfolio/css/cubeportfolio.min.css')); ?>">
	<link href="<?php echo e(asset('css/nivo-lightbox.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('css/nivo-lightbox-theme/default/default.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/owl.carousel.css')); ?>" rel="stylesheet" media="screen" />
    <link href="<?php echo e(asset('css/owl.theme.css')); ?>" rel="stylesheet" media="screen" />
	<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

	<!-- boxed bg -->
	<link id="bodybg" href="<?php echo e(asset('bodybg/bg1.css')); ?>" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="<?php echo e(asset('color/default.css')); ?>" rel="stylesheet">


</head>
<body>
<div id="wrapper">
	
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-6">
					<p class="bold text-left">Duyshembi - Shembi, 08:00 - 22:00 </p>
					</div>
					<div class="col-sm-6 col-md-6">
					<p class="bold text-right">Bizge qoniraw qilin +99899 999-99-99</p>
					</div>
				</div>
			</div>
		</div>
        <div class="container navigation">
		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="150" height="40" />
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			  <ul class="nav navbar-nav">
				<li class="active"><a href="#intro">Home</a></li>
				<li><a href="#service">Xizmetler</a></li>
				<li><a href="#doctor">Shipakerler</a></li>
				<li><a href="#facilities">Bizdegi imkaniyatlar</a></li>
				
				
			  </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	<section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
					<h2 class="h-ultra">Medicio medical group</h2>
					</div>
					<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
					<h4 class="h-light">Siz ushın <span class="color"> eń sapalı medicinalıq xızmetti </span> usınıs etemiz</h4>
					</div>
						<div class="well well-trans">
						<div class="wow fadeInRight" data-wow-delay="0.1s">

						<ul class="lead-list">
							<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Qaltanizga qolayli premium usinislar</strong></span></li>
							<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Ardaqlı shıpakerińizdi saylań </strong></span></li>
							<li><span class="fa fa-check fa-2x icon-success"></span> <span class="list"><strong>Tek dos sıpatında ortalıqtan paydalanıń </strong></span></li>
						</ul>

						</div>
						</div>


					</div>
								
				</div>		
			</div>
		</div>		
    </section>

<div class="cbp-l-member-info">
	<h1><div class="cbp-l-member-name"><?php echo e($category->name); ?></div></h1>
	
	<div class="cbp-l-member-desc">
		<?php echo e($category->description); ?>

	</div>
</div>
<section id="doctor" class="home-section bg-gray paddingbot-60">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow fadeInDown" data-wow-delay="0.1s">
					<div class="section-heading text-center">
					<h2 class="h-bold">Shipakerler</h2>
					
					</div>
					</div>
					<div class="divider-short"></div>
				</div>
			</div>
		</div>
		
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
				
            <div id="filters-container" class="cbp-l-filters-alignLeft">
              
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e(url('detail_category',$category->id)); ?>">
                	<div data-filter=".cardiologist" class="cbp-filter-item"><?php echo e($category->name); ?> </div>
				</a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
		
            <div id="grid-container" class="cbp-l-grid-team">
                <ul>
					<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="cbp-item psychiatrist">
                        <a href="doctors/member1.html" class="cbp-caption cbp-singlePage">
                            <div class="cbp-caption-defaultWrap">
                                <img src="<?php echo e(asset( $doctor->image )); ?>" alt="" width="100%">
                            </div>
                           
                        </a>
                        <p class="cbp-singlePage cbp-l-grid-team-name"><?php echo e($doctor->name); ?></p>
						
							<div class="cbp-l-grid-team-position">Is tajiriybesi <?php echo e($doctor->experience); ?> jil </div>
							
                        
                    </li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
			</div>
			</div>
		</div>

	</section>
	<footer>
		
			<div class="container">
				<div class="row">
					
					<div class="col-sm-6 col-md-4">
						<div class="wow fadeInDown" data-wow-delay="0.1s">
						<div class="widget">
							<h5>Medicio center</h5>
							
							<ul>
								<li>
									<span class="fa-stack fa-lg">
										<i class="fa fa-circle fa-stack-2x"></i>
										<i class="fa fa-calendar-o fa-stack-1x fa-inverse"></i>
									</span> Duyshembi - Shembi, 08:00 - 22:00
								</li>
								<li>
									<span class="fa-stack fa-lg">
										<i class="fa fa-circle fa-stack-2x"></i>
										<i class="fa fa-phone fa-stack-1x fa-inverse"></i>
									</span> +99899 999-99-99
								</li>
								<li>
									<span class="fa-stack fa-lg">
										<i class="fa fa-circle fa-stack-2x"></i>
										<i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i>
									</span> Medicio@gmail.com
								</li>

							</ul>
						</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4">
						<div class="wow fadeInDown" data-wow-delay="0.1s">
						<div class="widget">
							<h5>Manzil</h5>
							<p>Berdaq atındaǵı Qaraqalpaq Mámleketlik UniversitetiÓzbekstan, Qaraqalpaqstan Respublikası, Nókis qalası, SH.Abdirov kóshesi №1</p>		
							
						</div>
						</div>
						<div class="wow fadeInDown" data-wow-delay="0.1s">
						<div class="widget">
							<h5>Social tarmaqlar</h5>
							<ul class="company-social">
									<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
									<li class="social-vimeo"><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
									<li class="social-dribble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
							</ul>
						</div>
						</div>
					</div>
				</div>	
			</div>
			<div class="sub-footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-6">
						<div class="wow fadeInLeft" data-wow-delay="0.1s">
						<div class="text-left">
						<p>&copy;Copyright 2015 - Medicio. All rights reserved.</p>
						</div>
						</div>
					</div>
					
				</div>	
			</div>
			</div>
	</footer>
</div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>	 
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.scrollTo.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.appear.js')); ?>"></script>
	<script src="<?php echo e(asset('js/stellar.js')); ?>"></script>
	<script src="<?php echo e(asset('plugins/cubeportfolio/js/jquery.cubeportfolio.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/nivo-lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
		

</body>
<?php /**PATH C:\MAMP\htdocs\Medical_center\resources\views/detail_category.blade.php ENDPATH**/ ?>