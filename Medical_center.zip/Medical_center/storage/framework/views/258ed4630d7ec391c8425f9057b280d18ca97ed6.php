<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin_categories')); ?>">Back</a><br><br>
    <form action="<?php echo e(route('admin_categories.update',$category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" name="name" value="<?php echo e($category->name); ?>"> <br><br>
        <textarea name="description" placeholder="description" cols="30" rows="10"><?php echo e($category->description); ?></textarea><br><br>
        <input type="submit" style="color: red;" value="jiberiw">
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\Medical_center\resources\views/admin/category_edit.blade.php ENDPATH**/ ?>