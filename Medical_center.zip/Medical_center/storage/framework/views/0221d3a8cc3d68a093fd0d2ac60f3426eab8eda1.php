<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipakerler</title>
</head>
<body>
<a href="<?php echo e(url('admin')); ?>">Arqag'a</a><br><br>
<a href="<?php echo e(route('admin_doctors.create')); ?>">Shipakerlerdi qosiw</a><br><br>
<table border="1">
    <tr>
        <th>№</th>
        <th>F.I.O</th>
        <th>Bo'limi</th>
        <th>Is tajiriybesi / jil</th>
        <th>su'wret</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($doctor->name); ?></td>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($doctor->category_id == $category->id): ?>
                <td><?php echo e($category->name); ?></td>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($doctor->experience); ?></td>
            <td><img src="<?php echo e($doctor->image); ?>" width="100px" alt="img"></td>
            <td><a href="<?php echo e(route('admin_doctors.edit',$doctor->id)); ?>"><button>edit</button></a></td>
            <td><form action="<?php echo e(route('admin_doctors.destroy',$doctor)); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="delete">
                 </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
</body>
</html><?php /**PATH C:\MAMP\htdocs\Medical_center\resources\views/admin/doctors.blade.php ENDPATH**/ ?>