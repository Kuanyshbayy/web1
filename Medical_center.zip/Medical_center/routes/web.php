<?php

use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\DoctorController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\IndexController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/',[IndexController::class,'index']);
Route::get('/admin', function () {
    return view('login');
});
Route::post('login',[AuthController::class,'login']);
Route::get('detail_category/{id}',[IndexController::class,'detail_category']);

Route::resource('admin_categories',CategoryController::class);
Route::resource('admin_doctors',DoctorController::class);
